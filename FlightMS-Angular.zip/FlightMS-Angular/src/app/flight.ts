export class Flight {

    flightNumber:number;
    flightModel:string;
    carrierName:string;
    seatCapacity:number;

    //  constructor (flightNumber:number,flightModel:string,carrierName:string,seatCapacity:number){
    //     this.flightNumber=flightNumber;
    //     this.flightModel=flightModel;
    //     this.carrierName=carrierName;
    //     this.seatCapacity=seatCapacity;
    // }


}
